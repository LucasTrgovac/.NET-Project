﻿/*
Dieses Programm liest eine CSV-Datei von einer gegebenen URL und speichert sie lokal ab.
Es liest dann den Inhalt der lokalen Datei und bearbeitet die Daten, um den durchschnittlichen kumulierten Strom pro Tag zu erhalten.
Das Programm formatiert dann die Strom- und Datumsdaten in einen Diagrammtypen und erstellt HTML- und CSS-Dateien,
um den Graphen anzuzeigen, wobei das Datum auf der X-Achse und der durchschnittliche kumulierten Strom auf der Y-Achse angezeigt wird.
*/

// Importieren der notwendigen Namespaces.
using System;
using System.Net;
using System.IO;
using System.Collections;
using System.Globalization;

// Deklarieren der Hauptklasse des Programms.
namespace bwi40322 {
    class Program {
    // Definieren der Hauptmethode des Programms.
        static void Main(string[] args) {

            //Zeigt eine Nachricht an , die dem Benutzer mitteilt, dass das Programm startet. 
            Console.WriteLine("Programm startet");
            // Zeigt eine Nachricht an, die dem Benutzer mitteilt, dass der Dateilesevorgang begonnen hat.
            Console.WriteLine("Lese Datei...");

            /*****************************************************************
            Stage 1:  Daten vom Webserver holen
            *****************************************************************/

            // Definieren der URL der zu lesenden CSV-Datei.
            string csvUrl = "https://cbrell.de/bwi403/demo/ZaehlerstandExport.csv";

            // Verwendung der WebClient-Klasse, um den Inhalt der CSV-Datei von der URL zu lesen.
            WebClient wClient = new WebClient();
            // Die DownloadString-Methode liest den Dateiinhalt und gibt ihn als String zurück.
            string fileContents = wClient.DownloadString(csvUrl);
            // Verwerfen des Objektes.
            wClient.Dispose();
            // Prüfen, ob die Datei erfolgreich gelesen wurde.
            if(string.IsNullOrWhiteSpace(fileContents))
            {
                // Wenn die Datei keinen Inhalt hat, zeigt das Programm eine Nachricht an und beendet die Methode.
                Console.WriteLine("Die Datei ist leer.");
                // Die Methode wird den restlichen Code nicht ausführen.
                return;
            }
            // Zeigt eine Nachricht an, die dem Benutzer mitteilt, dass die Datei erfolgreich gelesen wurde.
            Console.WriteLine("Datei wurde erfolgreich gelesen.");

            /*****************************************************************
            Stage 2: Daten von Lokal laden und aufbereiten
            *****************************************************************/

            // Definieren des Namens der lokalen CSV-Datei, die erstellt werden soll.
            string fileName = "ein.csv";
            // Verwenden der File-Klasse, um den Inhalt der Datei in die lokale CSV-Datei zu schreiben.
            File.WriteAllText(fileName, fileContents);
            // Prüfen, ob die Datei erfolgreich erstellt wurde.
            if(File.Exists("ein.csv"))
            {
                // Wenn die Datei erfolgreich erstellt wurde, wird eine Nachricht dem Benutzer angezeigt.
                Console.WriteLine("Datei mit dem Namen '"+ fileName +"' auf dem lokalen Speicher erstellt.");
            }
            else
            {
                // Wenn beim Erstellen der Datei ein Fehler aufgetreten ist, wird eine Nachricht dem Benutzer angezeigt und die Methode wird verlassen.
                Console.WriteLine("Fehler beim Erstellen der Datei auf dem lokalen Speicher.");
                // Verlässt die Methode und die nächste Codezeile wird nicht ausgeführt.
                return;
            }

            Console.WriteLine("Lesen von Daten der lokalen Speicherdatei...");
            // Verwendung der StreamReader-Klasse, um den Inhalt der lokalen CSV-Datei zu lesen.
            StreamReader reader = new StreamReader(fileName);
            bool isHeaderLine = true;
            // Erstelle eine Liste, um die Daten zur Erstellung des Graphen zu speichern.
            List<GraphData> lstGraphData = new List<GraphData>();
            // Lese die Datei, bis das Dateiende erreicht ist.
            while(!reader.EndOfStream)
            {
                // Lese jede Zeile der Datei einzeln. Die Einträge in der Datei sind durch Zeilenumbrüche getrennt.
                string? record = reader.ReadLine();
                // Wenn der Eintrag nicht null oder leer ist, bearbeite ihn.
                if(!string.IsNullOrEmpty(record))
                {
                    // Wenn dies nicht die Kopfzeile (mit den Spaltennamen) ist, trenne den Eintrag durch Semikolons und füge die Daten der Liste zur weiteren Bearbeitung hinzu.
                    if(isHeaderLine == false)
                    {
                        string[] values = record.Split(";");
                        if(values.Length > 0)
                        {
                            GraphData item = new GraphData();
                            // Der erste Index ist die Uhrzeit.
                            item.ReadingTime = values[0];
                            // Der dritte Wert im Eintrag ist der kumulierte Strom.
                            item.ElectricityAverage = values[3];
                            lstGraphData.Add(item);
                        }
                    }
                    else
                    {
                        isHeaderLine = false;
                    }
                }
            }

            /*****************************************************************
            3. Daten transformieren, Kennzahl(en) erzeugen
            *****************************************************************/

            /* 
            Wir haben uns für den durchschnittlichen Stromverbrauch pro Tag entschieden, da man anhand dieser Kennzahl z.B die Energieeffizienz optimieren kann.
            Man könnte den Stromverbrauch pro Tag vergleichen und erkennen, an welchen Tagen man besonders viel Energie verbraucht und an welchen Tagen man sparsamer ist.
            */

            Console.WriteLine("Verarbeite Daten, um den durchschnittlichen Stromverbrauch pro Tag zu erhalten...");
            // Wenn die Liste Daten hat, verarbeite sie die Daten.
            if(lstGraphData.Count > 0)
            {
                // Erstelle Variablen für das Datum und den Stromverbrauch, um sie mit dem vorherigen Eintrag zu vergleichen.
                string readingDate = string.Empty;
                string electricity = string.Empty;
                // Erstelle eine Liste, um die endgültig verarbeiteten Daten für den Graph zu speichern.
                List<GraphData> lstFinal = new List<GraphData>();
                for(int count = 0; count < lstGraphData.Count; count++)
                {
                    // Datum und Uhrzeit haben ein Leerzeichen, da wir nur das Datum benötigen, also teilen wir es mit einem Leerzeichen, um das Datum zu erhalten.
                    string[] dateTime = (lstGraphData[count].ReadingTime).Split(" ");
                    if(dateTime.Length > 0)
                    {
                        // Hole den Datumsteil aus dem Datum und der Uhrzeit.
                        string date = dateTime[0];
                        if(count == 0)
                        {
                             readingDate = date;
                             electricity = lstGraphData[count].ElectricityAverage;
                        }
                       // Wenn das Datum des vorherigen und des aktuellen Eintrags übereinstimmt, wird es mit einem Semikolon verbunden.
                        if(readingDate == date)
                        {
                            readingDate = date;
                            electricity += ";" + lstGraphData[count].ElectricityAverage;
                        }
                        // Wenn das Datum des nächsten Eintrags nicht mit dem des vorherigen Eintrags übereinstimmt, wird der durchschnittliche Stromverbrauch in die Liste aufgenommen.
                        else if(readingDate != date)
                        {
                            decimal prevElec = 0;
                            GraphData gData = new GraphData();
                            gData.ReadingTime = readingDate;
                            string[] elecOnDate = electricity.Split(";");
                            int gapCount = 0;
                            for(int eCount = 0; eCount < elecOnDate.Length;eCount++)
                            {
                                if(eCount == 0)
                                {
                                    prevElec = ToDecimal(elecOnDate[eCount].Replace(",", "."));
                                    if(prevElec == 0)
                                    {
                                        gapCount++;
                                    }
                                }
                                // Wenn der Stromverbrauch > 0 ist, bedeutet dies keine Lücke.
                                else if(ToDecimal(elecOnDate[eCount].Replace(",", ".")) > 0)
                                {
                                    prevElec += ToDecimal(elecOnDate[eCount].Replace(",", "."));
                                }
                                else
                                {
                                    gapCount++;
                                }
                            }
                            // Berechnet den durchschnittlichen Stromverbrauch und rundet ihn auf eine Dezimalstelle.
                            gData.ElectricityAverage = Convert.ToString(Math.Round(prevElec / (elecOnDate.Length - gapCount), 1));
                            gapCount = 0;
                            lstFinal.Add(gData);

                            readingDate = date;
                            electricity = lstGraphData[count].ElectricityAverage;

                            // Wenn es sich um den letzten Eintrag handelt, füge ihn der Liste hinzu.
                            if(count == lstGraphData.Count - 1)
                            {
                                GraphData gData1 = new GraphData();
                                gData1.ElectricityAverage = Convert.ToString(lstGraphData[count].ElectricityAverage.Replace(",", "."));
                                gData1.ReadingTime = date;
                                lstFinal.Add(gData1);
                            }
                        }
                    }
                }

                /******************************************************************************************************
                4. Ausgaben / Visualisierung erzeugen und speichern
                *******************************************************************************************************/

                if(lstFinal.Count > 0)
                {
                    // Finde die minimalen und maximalen Werte in der Liste, die in der Tabelle für die y Achse verwendet werden.
                    decimal minValue = ToDecimal(lstFinal[0].ElectricityAverage);
                    decimal maxValue = ToDecimal(lstFinal[0].ElectricityAverage);
                    foreach(var val in lstFinal)
                    {
                        decimal value = ToDecimal(val.ElectricityAverage);
                        if(value < minValue)
                        {
                            minValue = value;
                        }
                        if(value > maxValue)
                        {
                            maxValue = value;
                        }
                    }

                    //Erstellung eines CSS Stylesheets, welches verwendet wird, um Elemente eines Graphen auf einer Webseite zu formatieren.
                    string indexCSS = @"
                    .electAvg-graph {
                        padding: 10px; 
                        height: 800px;
                        width: 7000px;
                    }

                    .electAvg-graph .x-labels {
                        text-anchor: middle;
                    }

                    .electAvg-graph .y-labels {
                        text-anchor: end;
                    }

                    .electAvg-graph .electAvg-graph-grid {
                        stroke: #ccc;
                        stroke-dasharray: 0;
                        stroke-width: 1;
                    }

                    .label-title {
                        text-anchor: middle;
                        text-transform: uppercase;
                        font-size: 16px;
                        fill: gray;
                    }

                    .electAvg-graph-dot{
                        fill: rgba(0,112,210,1);
                        stroke-width: 2;
                        stroke: white;   
                    }";

                    //Erstellen der index.css-Datei, die in der index.html-Datei verwendet wird.
                    File.WriteAllText("index.css", indexCSS);
                    Console.WriteLine("index.css Datei erfolgreich erstellt.");
                    
                    //Erstellen der HTML Datei  
                    string indexHtml=@"<html> 
                    <head>
                        <title>Durchschnittlicher Stromverbrauch pro Tag Liniendiagramm</title>
                        <link href='index.css' rel='stylesheet' type='text/css' >
                    </head>
                    <body>
                        <div>
                            <div>
                                <svg version='1.2' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' class='electAvg-graph'>
                                    <defs>
                                        <pattern id='grid' width='50' height='50' patternUnits='userSpaceOnUse'>
                                            <path d='M 50 0 L 0 0 0 50' fill='none' stroke='#e5e5e5' stroke-width='1'></path>
                                        </pattern>
                                    </defs>
                                    <rect x='50' width='6800px' height='755px' fill='url(#grid)' stroke='gray'></rect>
                                    <g class='label-title'>
                                        <text x='-300' y='70' transform='rotate(-90)'>Durschnitt Strom kwh kumuliert</text>
                                    </g>
                                    <g class='label-title'>
                                        <text x='15%' y='800'>Lucas Trgovac und Tim Jungblut</text>
                                    </g>
                                    <g class='x-labels'>
                                        @X_LABELS@
                                    </g>
                                    <g class='y-labels'>
                                        @Y_LABELS@
                                    </g>
            
                                    <polyline fill='none' stroke='#34becd' stroke-width='2' points='
			                        @POINTS@
                                    '></polyline>
                                    <g>
                                        @CIRCLES@
                                    </g>
                                </svg>
                            </div>
                        </div>
                    </body>
                    </html>";

                    // Berechnung der Höhe der Y-Achse des Diagramms
                    int maxY = (int)maxValue;

                    // Initialisierung der Variablen für die Erstellung des Diagramms
                    string xlabels = "";
                    string ylabels = "";
                    string points = "";
                    string circles = "";

                    // Initialisierung des aktuellen X-Werts und des Dictionaries, das die Beziehung zwischen Datum und X-Wert enthält
                    int xVal = 50;
                    Dictionary<DateTime, int> dateInHorizontal = new Dictionary<DateTime, int>();

                    // Schleife durch die Liste "lstFinal" um das Datum und den X-Wert hinzuzufügen und X-Achsenbeschriftungen zu erstellen
                    foreach(var lst in lstFinal) {

                        string label = lst.ReadingTime;
                        dateInHorizontal.Add(Convert.ToDateTime(lst.ReadingTime), xVal);
                        xlabels += "<text x='"+ xVal +"' y='770'>"+lst.ReadingTime+"</text>";
                        xVal += 100;
                    }

                    // Schleife durch die Liste "lstFinal" um die Y-Koordinate jedes Punkts zu berechnen und Punkte und Kreise zu erstellen
                    foreach(var val in lstFinal) {
                        int x;
                        if(!dateInHorizontal.TryGetValue(Convert.ToDateTime(val.ReadingTime), out x))
                        {
                            continue;
                        }

                        decimal diff = ToDecimal(val.ElectricityAverage) - minValue;
                        int y = 755 - (int)diff;
                        points += x+","+y +"\n\r";
                        circles += "<circle class='electAvg-graph-dot' cx='"+x+"' cy='"+y+"' r='6'></circle>";
                    }

                    // Initialisierung des Y-Wertes und Erstellung der Y-Achsenbeschriftungen
                    int y_Val = 755; 
                
                    int m_val = (int) minValue;
                    for(int count = 0; count < 16; count++) {
                        if(y_Val == 5)
                        y_Val = 15;

                        ylabels += "<text x='50' y='"+y_Val+"'>"+ m_val +"</text>";
                        y_Val -= 50;
                        m_val += 50;
                    }

                    //Ersetzen von XLables, YLabels, Punkte und Kreise in einer HTML-Datei.
                    indexHtml=indexHtml.Replace("@X_LABELS@", xlabels).Replace("@Y_LABELS@", ylabels).Replace("@POINTS@", points).Replace("@CIRCLES@", circles);
            
                    //Erstellen der Datei index.html, die das Diagramm enthält.
                    File.WriteAllText("index.html", indexHtml);
            
                    Console.WriteLine("Das Diagramm wird in der Datei index.html erstellt.");

                    string txtFile = "Berechnung des durchschnittlichen Stromverbrauchs pro Tag.\n\n";
                    foreach(var elec in lstFinal) 
                    {
                        txtFile+= "Datum: " +elec.ReadingTime + ", Durschnitt Strom: " + elec.ElectricityAverage + "\n"; 
                    }
                    File.WriteAllText("kennzahlen.txt", txtFile);
                    Console.WriteLine("Liniendiagrammbezogene Daten werden in der Datei kennzahlen.txt gespeichert.");

                    Console.WriteLine("Programm beendet.");
                }
            }
        }

        //--------------------------------

        //Erstelle eine Klasse, um Daten in eine Liste einzufügen, um sie im Diagramm / Graph anzuzeigen
        public class GraphData
        {
        public string ReadingTime {get; set;} = string.Empty;

        public string ElectricityAverage {get; set; } = string.Empty;
        }

        /*
         Konvertiert den angegebenen String-Wert in einen Dezimalwert. Erstelle diese Methode, um den Nullreferencefehler zu vermeiden.
         Ersetzt alle Punktzeichen durch Kommas und analysiert dann die Zeichenfolge unter Verwendung der deutschen Kultur.
         Wenn der String null oder leer ist, wird 0 zurückgegeben.
         Wenn die Zeichenfolge nicht in einen Dezimalwert umgewandelt werden kann, wird 0 zurückgegeben.
        */
        public static decimal ToDecimal(string value)
        {
            try{
            if(!string.IsNullOrEmpty(value))
            {
                // Ersetze alle Punktzeichen durch Kommas
                string str = value.Replace(".", ",");
                // Setze die aktuelle Kultur auf Deutsch
                Thread.CurrentThread.CurrentCulture = new CultureInfo("de-DE");
                // Analysiert die Zeichenfolge unter Verwendung der deutschen Kultur
                decimal rValue = Decimal.Parse(str, Thread.CurrentThread.CurrentCulture.NumberFormat);
                return rValue;
            }
            else
            {
                // Gebe 0 zurück, wenn die Zeichenfolge null oder leer ist
                return 0;
            }
            }
            catch
            {
                // Gebe 0 zurück, wenn während der Konvertierung eine Ausnahme ausgelöst wurde
                return 0;
            }
        }

        /* 
        Konvertiert den angegebenen String-Wert in eine Gleitkommazahl.
        Wenn der String null oder leer ist, wird 0.0 zurückgegeben.
        Wenn die Zeichenfolge nicht in eine Gleitkommazahl umgewandelt werden kann, wird 0.0 zurückgegeben.
         */
        public static double ToDouble(string value)
        {
            try
            {
                if(!string.IsNullOrEmpty(value))
                    {
                        // Versuche, die Zeichenfolge in eine Gleitkommazahl zu konvertieren.
                        return Convert.ToDouble(value);
                    }
                    else
                    {
                        // Gebe 0.0 zurück, wenn die Zeichenfolge null oder leer ist
                        return 0.0;
                    }
            }
            catch
            {
                // Gebe 0.0 zurück, wenn während der Konvertierung eine Ausnahme ausgelöst wurde
                return 0.0;
            }
        }
    }
}